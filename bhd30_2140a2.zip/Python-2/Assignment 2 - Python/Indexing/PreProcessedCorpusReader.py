
import Classes.Path as Path
import os

# Please explain the code with necessary comments.

class PreprocessedCorpusReader:
    def __init__(self, type): 
        # Initializing the class by selecting the appropriate files (trecweb or trectext).
        if type == "trecweb":
            # Path for the trecweb file taken from Path folder.
            self.file_path = os.path.join(Path.ResultHM1, "result.trecweb")
        elif type == "trectext":
            # Path for trectext file taken from Path folder.
            self.file_path = os.path.join(Path.ResultHM1, "result.trectext")
    
        # Opening the file in read mode and storing the file object.
        self.file = open(self.file_path, 'r', encoding='utf-8')  

    # Reading a line for docNo from the corpus, reading another line for the content, and returning them in [docNo, content].
    def nextDocument(self):
        # Reading the first line for docNo
        docno = self.file.readline().strip()  # Read and strip the docNo line

        # Checking if we've reached the end of the file
        if not docno:
            return None

        # Reading the second line for content
        content = self.file.readline().strip()  # Reading and slicing the content line

        # Checking if the content line is empty, indicating the end of the file
        if not content:
            return None

        # Returning the docNo and content
        return [docno, content]
