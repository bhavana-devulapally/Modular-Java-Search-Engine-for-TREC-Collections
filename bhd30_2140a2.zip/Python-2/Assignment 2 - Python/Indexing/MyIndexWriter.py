
import pickle
from collections import defaultdict
import Classes.Path as Path

# Efficiency and memory cost should be paid with extra attention.
# Please explain the code with necessary comments.

# The below class handles the creation of an inverted index from the documents processed.
class MyIndexWriter:

    def __init__(self, doc_type):
        # Initializing structures for indexing and store file paths based on the document type.
        self.term_dict = {}  # In-memory structure for the term index
        self.doc_id_map = {}  # Maps docNo to docId
        self.current_doc_id = 0  # Current integer docId to assign
        
        # Define file paths for storing the index
        if doc_type == "trecweb":
            self.dict_file_path = Path.IndexWebDir + "dict.txt"
            self.postings_file_path = Path.IndexWebDir + "postings_list.pkl"
            self.doc_id_map_file_path = Path.IndexWebDir + "doc_id_map.pkl"
        elif doc_type == "trectext":
            self.dict_file_path = Path.IndexTextDir + "dict.pkl"
            self.postings_file_path = Path.IndexTextDir + "postings_list.pkl"
            self.doc_id_map_file_path = Path.IndexTextDir + "doc_id_map.pkl"

    # This method processes a document to index its terms and update the index structures.
    # The below index method builds index for each document.
    # NT: in your implementation of the index, you should transform your string docno into non-negative integer docids,
    # and in MyIndexReader, you should be able to request the integer docid for each docno.
    def index(self, docNo, content):
        # If the document number is new, assign a new docId
        docId = self.doc_id_map.setdefault(docNo, self.current_doc_id)
        if docId == self.current_doc_id:
            self.current_doc_id += 1  # Increment for the next document if a new one is added

        # Tokenize the content into terms
        terms = content.split()

        # Count term frequency within the document
        term_frequency = defaultdict(int)
        for term in terms:
            term_frequency[term] += 1

        # Update the term index with the new frequencies
        for term, freq in term_frequency.items():
            if term not in self.term_dict:
                self.term_dict[term] = [0, 0, []]  # [collection frequency, document frequency, posting list]
            
            # Update collection and document frequencies
            self.term_dict[term][0] += freq  # Increment collection frequency
            self.term_dict[term][1] += 1  # Increment document frequency
            self.term_dict[term][2].append((docId, freq))  # Append docId and frequency to postings

    # Close the index writer and save all indexed data to disk
    # Close the index writer, and you should output all the buffered content (if any).
    def close(self):
        with open(self.dict_file_path, 'wb') as dict_file:
            pickle.dump(self.term_dict, dict_file)

        with open(self.doc_id_map_file_path, 'wb') as doc_id_file:
            pickle.dump(self.doc_id_map, doc_id_file)

        # Prepare and save postings data to disk
        postings_data = {term: postings for term, (_, _, postings) in self.term_dict.items()}
        with open(self.postings_file_path, 'wb') as postings_file:
            pickle.dump(postings_data, postings_file)
