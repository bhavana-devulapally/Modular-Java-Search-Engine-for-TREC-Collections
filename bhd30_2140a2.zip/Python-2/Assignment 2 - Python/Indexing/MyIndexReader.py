
import Classes.Path as Path
import pickle

# The below class reads an inverted index from the disk for querying.
class MyIndexReader:

    def __init__(self, doc_type):
        # Setting up paths for index files based on the document type
        self.type = doc_type
        
        #If the doc type is trecweb.
        if doc_type == "trecweb":
            #Adding the indexes to files dict.pk1 , postings having information about word frequency and index information
            self.dict_file_path = Path.IndexWebDir + "dict.txt"
            self.postings_file_path = Path.IndexWebDir + "postings_list.pkl"
            self.doc_id_map_file_path = Path.IndexWebDir + "doc_id_map.pkl"

        #If the doc type is trectext.
        elif doc_type == "trectext":
            #Adding the indexes to files dict.pk1 , postings having information about word frequency and index information
            self.dict_file_path = Path.IndexTextDir + "dict.pkl"
            self.postings_file_path = Path.IndexTextDir + "postings_list.pkl"
            self.doc_id_map_file_path = Path.IndexTextDir + "doc_id_map.pkl"

        # Loading the index files into memory
        self.loadIndex() 
        print("finish reading the index")

    # Loading index data from files into memory
    def loadIndex(self):
        with open(self.dict_file_path, 'rb') as dict_file:
            self.term_dict = pickle.load(dict_file)
        
        with open(self.postings_file_path, 'rb') as postings_file:
            self.postings = pickle.load(postings_file)
        
        with open(self.doc_id_map_file_path, 'rb') as doc_id_file:
            self.doc_id_map = pickle.load(doc_id_file)

    # Retrieving the document ID for a specific document number
    def getDocId(self, docNo):
        return self.doc_id_map.get(docNo, -1)  # Returning -1 if not found

    # Retrieving the document number for a specific document ID
    def getDocNo(self, docId):
        # Iterating through the doc_id_map to find the corresponding docNo
        for docNo, id in self.doc_id_map.items():
            if id == docId:
                return docNo
        return -1  # Return -1 if not found

    # Retrieving document frequency for a specific token
    def DocFreq(self, token):
        return self.term_dict.get(token, [0, 0])[1]  # Returning 0 if the token not found

    # Retrieve collection frequency for a specific token
    def CollectionFreq(self, token):
        return self.term_dict.get(token, [0, 0])[0]  # Returning 0 if the token not found

    # Retrieving the posting list for a given token
    def getPostingList(self, token):
        if token in self.term_dict:
            posting_list = {docId: freq for docId, freq in self.term_dict[token][2]}
            return posting_list
        return {}  # Returning empty dict if token not found
