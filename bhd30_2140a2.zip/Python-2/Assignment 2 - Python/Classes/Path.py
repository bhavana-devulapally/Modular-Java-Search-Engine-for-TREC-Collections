
# uncompleted address of preprocessed corpus.
ResultHM1="data//result//"

# address of generated Text index file.
IndexTextDir="data//indextext//"

# address of generated Web index file.
IndexWebDir="data//indexweb//"