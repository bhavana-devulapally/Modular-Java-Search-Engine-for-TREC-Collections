import math
from collections import defaultdict
from Classes.Document import Document
from SearchWithWhoosh.QueryRetreivalModel import QueryRetrievalModel


class PseudoRFRetrievalModel:

    def __init__(self, ixReader):
        self.indexReader = ixReader

    def retrieveQuery(self, query, topN, topK, alpha):
        # Step 1: Get topK feedback documents
        feedback_docs = self._initialRetrieval(query, topK)

        # Step 2: Calculate P(token | feedback documents)
        token_rf_score = self.GetTokenRFScore(query, feedback_docs)

        # Step 3: Score all documents using the pseudo relevance feedback model
        top_docs = self._scoreDocuments(query, token_rf_score, topN, alpha)

        return top_docs

    def GetTokenRFScore(self, query, feedback_docs):
        token_rf_score = {}
        term_freqs = defaultdict(int)
        query_terms = query.queryContent.split()

        # Aggregate pseudo document length
        pseudo_doc_length = sum(
            self.indexReader.getDocLength(self.indexReader.getDocId(doc.docno))
            for doc in feedback_docs
        )

        # Compute term frequencies for feedback documents
        for term in query_terms:
            term_freq = 0
            posting_list = self.indexReader.getPostingList(term)
            for doc in feedback_docs:
                doc_id = self.indexReader.getDocId(doc.docno)
                term_freq += posting_list.get(doc_id, 0)
            term_freqs[term] = term_freq

        # Calculating token relevance feedback scores with Dirichlet smoothing
        doc_count = self.indexReader.searcher.doc_count_all()
        mu = 3000  # Dirichlet smoothing parameter
        for term in query_terms:
            collection_freq = self.indexReader.CollectionFreq(term)
            term_freq = term_freqs[term]
            token_rf_score[term] = (term_freq + mu * (collection_freq / doc_count)) / (pseudo_doc_length + mu)

        return token_rf_score

    def _scoreDocuments(self, query, token_rf_score, topN, alpha):
        query_terms = query.queryContent.split()
        mu = 3000  # Dirichlet smoothing parameter
        doc_count = self.indexReader.searcher.doc_count_all()

        # Cache collection frequencies for better access and efficiency
        collection_freqs = {term: self.indexReader.CollectionFreq(term) for term in query_terms}
        posting_lists = {term: self.indexReader.getPostingList(term) for term in query_terms}

        doc_scores = {}

        for doc_id in range(doc_count):
            doc_length = self.indexReader.getDocLength(doc_id)
            score = 0.0

            for term in query_terms:
                tf = posting_lists[term].get(doc_id, 0)
                collection_freq = collection_freqs[term]

                # P(term | document) with Dirichlet smoothing
                p_qi_d = (tf + mu * (collection_freq / doc_count)) / (doc_length + mu)

                # P(term | feedback documents)
                p_qi_feedback = token_rf_score.get(term, 0)

                # Combining scores
                term_score = alpha * p_qi_d + (1 - alpha) * p_qi_feedback
                if term_score > 0:
                    score += math.log(term_score)

            doc_scores[doc_id] = score

        # Sorting documents by score and retrieve the topN
        sorted_docs = sorted(doc_scores.items(), key=lambda x: x[1], reverse=True)[:topN]

        result_documents = []
        for doc_id, score in sorted_docs:
            doc_no = self.indexReader.getDocNo(doc_id)
            doc = Document()
            doc.setDocNo(doc_no)
            doc.setScore(score)
            result_documents.append(doc)

        return result_documents

    def _initialRetrieval(self, query, topK):
        query_model = QueryRetrievalModel(self.indexReader)
        return query_model.retrieveQuery(query, topK)


