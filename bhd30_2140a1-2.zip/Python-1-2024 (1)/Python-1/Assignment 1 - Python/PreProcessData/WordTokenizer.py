# import Classes.Path as Path

# Efficiency and memory cost should be paid with extra attention.
# Essential private methods or variables can be added.

# Please add comments along with your code.

import Classes.Path as Path
import re  

class WordTokenizer:
    #This class is used to distinguish words. The parder would read every charecter and identify words.
    def __init__(self, content):
        # Sequentially reading words from a sequence of characters and Tokenizing the input text by splitting based on all the non-word characters. 
        self.words = re.findall(r'\b\w+\b', content) 
        self.current_index = 0  # Tracking the current word index

    def nextWord(self):
        # Returning the next word in the document or None if it is at the end
        if self.current_index < len(self.words):
            word = self.words[self.current_index]
            self.current_index = self.current_index+ 1
            return word  # Returning the next word
        else:
            return None  # Returning None when there are no more words
