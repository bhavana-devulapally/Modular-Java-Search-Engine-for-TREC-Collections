# Efficiency and memory cost should be paid with extra attention.
# Essential private methods or variables can be added.

import Classes.Path as Path

class StopWordRemover:
    #Based on all the words given inside the Stopwords.txt document all those words are removed 
    def __init__(self):
        self.stop_words = set()  # Using a set for efficient lookups so that it can handle duplicates
        # Load and store stop words from the file using a set during initialization
        with open(Path.StopwordDir, 'r') as file:
            for line in file:
                word = line.strip()  # Removing any whitespaces present
                self.stop_words.add(word)  # Adding the word to the set

    def isStopword(self, word):
        # Returning true if the input word is a stop word, or false if not
        if word in self.stop_words:
            return True
        else:
            return False
        