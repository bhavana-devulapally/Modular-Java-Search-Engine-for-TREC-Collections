# Efficiency and memory cost should be paid with extra attention.
# Essential private methods or variables can be added.

import Classes.Path as Path
from nltk.stem import PorterStemmer

class WordNormalizer:
    #This class is used to perform stemming on each word using the PorterStemmer library
    def __init__(self):
        self.stemmer = PorterStemmer()  # Initializing the Porter Stemmer to STEM the word.
        self.stem_cache = {}  # Initializing a cache for stemming to remember the words on which stemming has already been performed and stores in the cache. This eventually reduces a lot a time while compiling as first it would check the cache and if not present in cache it would scan the document.

    def lowercase(self, word):
        # Transforming words into lowercase.
        return word.lower() 

    def stem(self, word):
        # Check if the word is already in the cache. If present we just return the word from the cache.
        if word in self.stem_cache:
            return self.stem_cache[word]  # Return cached result

        # If not in cache, we stem the word and store it in the cache
        stemmed_word = self.stemmer.stem(word)  # Using the stemmer to get the stemmed word
        self.stem_cache[word] = stemmed_word  # Cache the result (Storing the word in the cache)
        return stemmed_word  # Returning the stemmed word
        #As its stored in the cache now , next time it encounters the same word it would first search in the cache and as it would already be there in the cache it would process it directly. This will reduce the processing time to a great extinct.
