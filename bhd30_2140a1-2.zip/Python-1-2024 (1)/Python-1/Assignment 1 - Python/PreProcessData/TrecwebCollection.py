
# Efficiency and memory cost should be paid with extra attention.
# Essential private methods or variables can be added.

# Please add comments along with your code.

import Classes.Path as Path
import re

class TrecwebCollection:

    def __init__(self):
        # Initialize and open the TREC web file for reading
        self.file_path = Path.DataWebDir
        # 1. Opening the file in Path.DataWebDir.
        self.file = open(self.file_path, 'r', encoding='utf-8')
        self.reached_end = False  # Track if we've reached the end of the file

    def nextDocument(self):
        if self.reached_end:
            return None
        # When called, this method process one document from corpus, and returns the corresponding doc number and content.
        docNo = ""
        content = ""
        inside_content = False  # Tracking if we're inside the document content

        for line in self.file:
            line = line.strip()  # Cleanng up any extra spaces present

            if line.startswith("<DOCNO>"):
                # Extracting the document number using regex
                docNo = re.search(r"<DOCNO>(.*?)</DOCNO>", line).group(1).strip()
            elif line == "</DOCHDR>":
                # After </DOCHDR>, start taking in the document content
                inside_content = True
            elif line == "</DOC>":
                # When </DOC> is encountered, return the document number and cleaned content
                cleaned_content = self.clean(content)  # Remove HTML tags
                return [docNo, ' '.join(cleaned_content.split())]  # Clean and return the content
            elif inside_content:
                # Accumulating content between </DOCHDR> and </DOC> and storing it in content
                content += line + " "

       
        # If we reach the end of the file, close it
        self.reached_end = True
        self.file.close()
        return None

    def clean(self, text):
        # Removeing all the HTML tags using regular expressions
        # 3. the HTML tags should be removed in document content.
        clean = re.compile('<.*?>')
        return re.sub(clean, '', text)
