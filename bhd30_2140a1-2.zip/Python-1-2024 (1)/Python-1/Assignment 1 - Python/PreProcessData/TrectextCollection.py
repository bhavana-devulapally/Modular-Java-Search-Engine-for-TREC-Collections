import Classes.Path as Path

class TrectextCollection:
    def __init__(self):
        # Initializing the file path 
        self.file_path = Path.DataTextDir  # Path to the trectext file
        #1.) Opening the file in Path.DataTextDir in read mode.
        self.file = open(self.file_path, 'r', encoding='utf-8')
        self.current_doc = None
    #Processing is done for every document individually
    def nextDocument(self):
        # 2) Function to process the next document
        # When called, this API processes one document from corpus, and returns its doc number and content.
        docNo = ""
        content = ""
        doc_started = False
        content_started = False
        # If it encounters <DOC> it would start adding the content to content and maintains a flag and sets it to True . Once </DOC> comes it stops adding the content to "content" and makes the flag "False"
        for line in self.file:
            line = line.strip()

            if line == "<DOC>":
                doc_started = True
                docNo = ""
                content = ""
                continue

            if line == "</DOC>":
                doc_started = False
                return [docNo, content]  # Returning the docID and its content when we reach </DOC>

            if doc_started:
                if "<DOCNO>" in line:
                    docNo = line.replace("<DOCNO>", "").replace("</DOCNO>", "").strip()
                # When <TEXT> is encountered in the document it would make the flag to True and start adding the document content to "content"
                elif "<TEXT>" in line:
                    content_started = True
                # When </TEXT> is encountered it makes the flag(content_started) "False" indicating that it should stop taking in the content into the variable "content"
                elif "</TEXT>" in line:
                    content_started = False
                elif content_started:
                    content = content+ line + " "

        # If there is no document is left, I'm returning null and closing the file
        self.file.close()
        return None