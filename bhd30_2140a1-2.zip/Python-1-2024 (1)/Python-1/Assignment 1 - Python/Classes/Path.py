# you should specify and put all files in the corresponding directory
# address of target corpus docset.trectext.
DataTextDir = "data//output//docset.trectext"
#DataTextDir = "C:\\Users\\bhava\\Downloads\\Python-1-2024 (1)\\Python-1\\Assignment 1 - Python\\PreProcessData\\docset.trectext"

# address of target corpus docset.trecweb.
DataWebDir = "data//output//docset.trecweb"

# address of stopword list.
StopwordDir="data//input//stopword.txt"

# uncompleted address of preprocessed corpus.
ResultHM1="data//result//"

# address of generated Text index file.
IndexTextDir="data//indextext//"

# address of generated Web index file.
IndexWebDir="data//indexweb//"
