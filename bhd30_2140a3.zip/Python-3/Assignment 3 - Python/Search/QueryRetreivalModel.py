import math
from collections import defaultdict, deque
from Classes.Document import Document  # Ensure Document is imported

class QueryRetrievalModel:
    
    def __init__(self, ixReader):
        self.indexReader = ixReader  # Initialize with the index reader
    
    def retrieveQuery(self, queries, topN):
        # Ensuring queries is a list (even if a single query is passed)
        if not isinstance(queries, list):
            queries = [queries]  # Wrap the single query in a list

        # Initializing smoothing parameter mu (Dirichlet smoothing)
        mu = 9000  # This value can be tuned

        # Getting the searcher object from indexReader
        searcher = self.indexReader.searcher
        
        # Getting the total number of documents in the collection
        doc_count = searcher.doc_count_all()

        # Precomputing document lengths and collection frequencies to avoid redundant calculations
        collection_freqs = {}  # Collection frequency for each term
        doc_lengths = {}  # Length of each document
        posting_lists = {}  # Posting list for each term

        # Precomputing document lengths
        for doc_id in range(doc_count):
            doc_lengths[doc_id] = self.indexReader.getDocLength(doc_id)
        
        # Precomputing collection frequencies and posting lists for all terms across queries
        terms_in_collection = set()  # Unique terms across all queries
        for query in queries:
            query_terms = query.queryContent.split()
            terms_in_collection.update(query_terms)

        # Caching posting lists and collection frequencies
        for term in terms_in_collection:
            posting_lists[term] = self.indexReader.getPostingList(term)
            collection_freqs[term] = self.indexReader.CollectionFreq(term)

        # Initializing a dictionary to hold the document scores for all documents
        document_scores = defaultdict(float)

        # For each query, calculating its contribution to the document scores
        for query in queries:
            query_terms = query.queryContent.split()

            for doc_id in range(doc_count):  # Iterate through all documents in the index
                doc_length = doc_lengths[doc_id]  # Get the length of the document
                score = 0.0  # Initialize the document score for this query

                # For each term in the query, calculate its contribution to the document's score
                for term in query_terms:
                    # Get the term frequency in the document from the cached posting list
                    tf = posting_lists[term].get(doc_id, 0)

                    # Get the collection frequency for the term (already precomputed)
                    collection_freq = collection_freqs[term]

                    # Calculate the smoothed probability for the term in the document
                    term_prob = (tf + mu * (collection_freq / doc_count)) / (doc_length + mu)

                    # If the term probability is non-zero, add its log to the score
                    if term_prob > 0:
                        score += math.log(term_prob)

                # Accumulate the score for this document across all queries
                document_scores[doc_id] += score

        # Using a deque to store the top N documents efficiently
        top_documents = deque(maxlen=topN)

        # Adding documents to the deque and keep only the top N sorted by score
        for doc_id, score in document_scores.items():
            doc_no = self.indexReader.getDocNo(doc_id)  # Get the document number using the doc ID
            top_documents.append((doc_no, score))
            top_documents = deque(sorted(top_documents, key=lambda x: x[1], reverse=True), maxlen=topN)

        # Returning the top N documents (convert to Document objects)
        result_documents = []
        for doc_no, score in top_documents:
            doc = Document()  # Create a new Document instance
            doc.setDocNo(doc_no)  # Set the doc number
            doc.setScore(score)  # Set the score
            result_documents.append(doc)  # Add to the result list

        return result_documents