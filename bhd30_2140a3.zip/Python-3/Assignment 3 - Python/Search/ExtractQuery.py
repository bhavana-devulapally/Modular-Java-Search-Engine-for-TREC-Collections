import Classes.Query as Query
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from Classes import Path

class ExtractQuery:

    def __init__(self):
        # 1. Reading the topics.txt file and extract the queries
        self.queries = []
        self.stop_words = self.load_stopwords()
        self.stemmer = PorterStemmer()
        self.extract_queries()

    def load_stopwords(self):
        stop_words = set()
        with open(Path.StopWordDir, 'r') as file:
            for line in file:
                stop_words.add(line.strip().lower())
        return stop_words

    def preprocess_query(self, query_content):
        # 2. Tokenizing, lowercase, remove stopwords, and apply stemming
        tokens = word_tokenize(query_content.lower())  # Tokenize and convert to lowercase
        filtered_tokens = [self.stemmer.stem(word) for word in tokens if word.isalnum() and word not in self.stop_words]
        return " ".join(filtered_tokens)

    def extract_queries(self):
        # Opening topics.txt and extract the title for each topic
        with open(Path.TopicDir, 'r') as file:
            topic = ""
            topic_id = ""
            title = ""
            for line in file:
                line = line.strip()

                if line.startswith('<top>'):
                    # Reset topic data
                    topic = ""
                    title = ""
                elif line.startswith('<num>'):
                    topic_id = line.split('Number:')[1].strip()
                elif line.startswith('<title>'):
                    title = line.split('title>')[1].strip()
                elif line.startswith('</top>'):
                    # Preprocess the title and store the query
                    preprocessed_query = self.preprocess_query(title)
                    query = Query.Query()
                    query.setTopicId(topic_id)
                    query.setQueryContent(preprocessed_query)
                    self.queries.append(query)

    def getQueries(self):
        return self.queries